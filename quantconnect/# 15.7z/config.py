#region imports
from AlgorithmImports import *
#endregion

VOL_MA = 40
VWMA_FASTEST = 20
VWMA_FAST = 50
VWMA_SLOW = 100
VWMA_SLOWEST = 200

VOL_OSC_SHORT = 25
VOL_OSC_LONG = 50

PGO_LB_LENGTH = 89

TSI_LONG = 25
TSI_SHORT = 13
TSI_SIGNAL = 13

RVGI_LENGTH = 21

STC_LENGTH = 12
STC_FAST = 26
STC_SLOW = 50
STC_AAA = 0.5

KRI_LENGTH = 28

VWAP_LENGTH = 24 # 1D(24 Hours) / Resolution.Hour
